Quick introduction:
	In total there are five of these games, each with a different theme and about 35 levels to play.
	These are: 1 - The Forest Temple, 2 - The Light Temple, 3 - The Ice Temple, 4 - The Crystal Temple and 5 - Elements.
	All of these are available online but those sites spam you with adds, can be unstable, etc, etc...
	
	At some point Elements was made available on Steam. It has a price tag but to me it's worth 0.79 Euro if it means I can play locally.
	Now for the reason this exists: only Elements is available and while it is a sort of combination of the themes of the previous games
	 and some new ones, it doesn't have any of the previous levels.
	However it turns out it is fairly easy to get the old levels to run inside of Elements.


Some basic info:

	Main files should be in:
		C:\Program Files (x86)\Steam\steamapps\common\Fireboy & Watergirl Elements\resources\app\www

	Progression is stored in:
		C:\Users\[YOUR NAME]\AppData\Roaming\com.osloalbet.fb\Local Storage\leveldb

You should back-up both of these folders before modifying anything.
I included back-ups of everything I changed but I won't be held accountable in case anything goes wrong.


Everything from the "www" and "Optional Transparent Menu" needs to go in to the main file folder. Overwrite everything.
There's a screenshot in case you're unsure about the optional menu.


If you want to run the game in fullscreen you can use something like this:
	http://runtimeterror.com/tools/fullscreenizer/

